Somewhat unused for UNI2, mostly for the compression that MBTL deals with so we can get their PAT assets.

You can drag and drop your DDS file to the batch files to perform the respective operation.